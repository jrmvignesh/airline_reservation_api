package edu.sjsu.cmpe275.lab2;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirlineReservationApiApplication {

	public static void main(String[] args) {
		
		SpringApplication.run(AirlineReservationApiApplication.class, args);
	}
}

